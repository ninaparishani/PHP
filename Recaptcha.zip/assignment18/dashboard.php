<?php
session_start(); 
include 'php/header.php';

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php"); 
    exit();
}

// Check if username is stored in session
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/styles2.css">
</head>
<body>
    <div class="container">
        <h2>Welcome to the Dashboard</h2>
        <p>You are logged in as <?= htmlspecialchars($username); ?></p>

        <h3>Assignment Overview</h3>
        <p>In this assignment, we have focused on implementing robust security measures for user registration and login. Here are the key features:</p>

        <ul>
            <li><strong>Login/Registration:</strong> The system allows users to register and log in using their credentials. Sessions are used to maintain user authentication across secure pages.</li>
            <li><strong>Session Management:</strong> After logging in successfully, a session is started to keep track of the user's login state, allowing seamless navigation within the application.</li>
            <li><strong>Exception Handling:</strong> I have integrated `try-catch` blocks to handle potential errors gracefully. This ensures that if any issues occur (e.g., database connection errors), the system logs these errors without disrupting the user experience.</li>
            <li><strong>Error Logging:</strong> Errors are logged to 'logerrors.txt', providing a way to track and debug issues efficiently. This log file captures any exceptions or errors encountered during user interactions.</li>
            <li><strong>Form Security:</strong> 
    
            <li><strong>CAPTCHA Integration:</strong> A CAPTCHA has been added to the registration form and login to prevent automated bot registrations.</li>
            <li><strong>Sanitization and Escaping:</strong> The `strip_tags()` function is used to sanitize user input by removing potentially harmful HTML or PHP tags. After validation, the `addslashes()` function is used to escape special characters in the data before inserting it into the database. However, `addslashes()` is not applied to predefined fields like 'terms' and 'province', or hashed passwords.</li>
    
            </li>
        </ul>

        <p>
            These measures ensure that the application remains secure, robust, and user-friendly while also allowing developers to diagnose and resolve any issues efficiently.
        </p>

        <a href="update.php">Update Your Information</a>
        <br>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>

<?php
include 'php/footer.php';
?>
