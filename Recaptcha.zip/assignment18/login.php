<?php
session_start();
require 'database.php'; 
include 'logerrors.php';
include 'php/header.php';

// Google reCAPTCHA v2 site key and secret key
$siteKey = '6LfcykUqAAAAAL45UpBNpYdkMq_joTK3fzLHvM3N'; 
$secretKey = '6LfcykUqAAAAACMKoOl9MZAbRlr88Lozd5pVTzO-';

// Check if user is already logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header("Location: dashboard.php"); 
    exit();
}

// Initialize variables for form fields and errors
$username = $password = '';
$loginError = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    try {
        // Sanitize and validate user input
        $username = strip_tags($_POST['username']);
        $password = strip_tags($_POST['password']);
        $captcha_response = $_POST['g-recaptcha-response'];

        // Validate CAPTCHA
        if (!$captcha_response || !validateCaptcha($captcha_response)) {
            throw new Exception("CAPTCHA validation failed.");
        }

        // Validate user input
        if (empty($username) || empty($password)) {
            throw new Exception("Username and password are required.");
        }

        // Escape user input for database query
        $username = addslashes($username);

        // Check user credentials
        $sql = "SELECT * FROM users WHERE username = '$username'";
        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
            // Verify password hash stored in the database with the entered password
            if (password_verify($password, $row['password'])) {
                // Successful login
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $username;
                header("Location: dashboard.php");
                exit();
            } else {
                throw new Exception("Invalid username or password.");
            }
        } else {
            throw new Exception("Invalid username or password.");
        }
    } catch (Exception $e) {
        // Log the error message and display it to the user
        logError($e->getMessage());
        $loginError = $e->getMessage(); 
    }
}

// Function to validate CAPTCHA response
function validateCaptcha($response) {
    global $secretKey;
    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$response");
    $responseKeys = json_decode($response, true);
    return intval($responseKeys['success']) === 1;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/styles2.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <?php if ($loginError) : ?>
            <div class="error"><?= htmlspecialchars($loginError); ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <!-- Google reCAPTCHA widget -->
            <div class="g-recaptcha" data-sitekey="<?= htmlspecialchars($siteKey); ?>"></div>

            <button type="submit" name="login">Login</button>
        </form>

        <p>Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</body>
</html>

<?php
include 'php/footer.php';
?>
