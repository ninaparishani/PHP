<footer>
    <p>&copy; 2024 Your Website</p>
</footer>
