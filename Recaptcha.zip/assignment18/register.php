<?php
session_start();
require 'database.php';
include 'logerrors.php';
include 'php/header.php';

date_default_timezone_set('America/New_York');

// Google reCAPTCHA keys
$siteKey = '6LfcykUqAAAAAL45UpBNpYdkMq_joTK3fzLHvM3N'; 
$secretKey = '6LfcykUqAAAAACMKoOl9MZAbRlr88Lozd5pVTzO-'; 

// Clear any existing session for previous users
if (isset($_SESSION['username'])) {
    session_unset(); 
    session_destroy(); 
}

if (isset($_POST['register'])) {
    try {
        // Retrieve and sanitize input using strip_tags
        $username = strip_tags($_POST['username']);
        $password = strip_tags($_POST['password']);
        $hashed_password = password_hash($password, PASSWORD_BCRYPT); // hash password, no need for addslashes
        $firstname = strip_tags($_POST['firstname']);
        $lastname = strip_tags($_POST['lastname']);
        $email = strip_tags($_POST['email']);
        $province = $_POST['province']; // predefined value, no need for sanitization
        $terms = $_POST['terms']; // predefined checkbox, no need for sanitization

        // Check if any field is empty
        if (empty($username) || empty($password) || empty($firstname) || empty($lastname) || empty($email) || empty($terms)) {
            throw new Exception('All fields are required.');
        }

        // Validate email format
        $emailPattern = "/^[\w\.-]+@[a-zA-Z\d\.-]+\.[a-zA-Z]{2,6}$/";
        if (!preg_match($emailPattern, $email)) {
            throw new Exception('Invalid email format.');
        }

        // CAPTCHA validation
        $captcha = $_POST['g-recaptcha-response'];
        $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$captcha");
        $responseKeys = json_decode($response, true);

        if (!$responseKeys['success']) {
            throw new Exception('Please complete the CAPTCHA.');
        }

        // Check if the username already exists
        $checkSql = "SELECT * FROM users WHERE username = ?";
        $stmt = mysqli_prepare($conn, $checkSql);
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            throw new Exception('Username already exists.');
        }

        // Insert new user into database
        $sql = "INSERT INTO users (username, password, firstname, lastname, email, province) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'ssssss', $username, $hashed_password, $firstname, $lastname, $email, $province);

        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception('Error registering user: ' . mysqli_error($conn));
        }

        // Redirect to login page after successful registration
        header("Location: login.php?registered=true");
        exit();

    } catch (Exception $e) {
        // Log errors and display a user-friendly message
        $timestamp = date('Y-m-d H:i:s');
        $message = "[$timestamp] Exception caught: " . $e->getMessage();
        logError($message);
        $registerError = "An error occurred during registration. Please try again later.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="css/styles2.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script> <!-- Add the reCAPTCHA script -->
</head>
<body>
    <div class="container">
        <h2>Register</h2>
        <?php if (isset($registerError)) : ?>
            <div class="error"><?= htmlspecialchars($registerError); ?></div>
        <?php endif; ?>
        <form method="POST" action="register.php">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <label for="firstname">First Name:</label>
            <input type="text" id="firstname" name="firstname" required>

            <label for="lastname">Last Name:</label>
            <input type="text" id="lastname" name="lastname" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="province">Province:</label>
            <select id="province" name="province" required>
                <option value="Ontario">Ontario</option>
                <option value="Quebec">Quebec</option>
                <option value="British Columbia">British Columbia</option>
                <option value="British Columbia">British Columbia</option>
                <option value="Alberta">Alberta</option>
                
            </select>

            <label>
                <input type="checkbox" name="terms" required> I agree to the terms and conditions
            </label>

            <!-- Google reCAPTCHA widget -->
            <div class="g-recaptcha" data-sitekey="<?= htmlspecialchars($siteKey); ?>"></div>

            <button type="submit" name="register">Register</button>
        </form>
        <p>Already have an account? <a href="login.php">Login here</a></p>
    </div>
</body>
</html>

<?php
include 'php/footer.php';
?>
