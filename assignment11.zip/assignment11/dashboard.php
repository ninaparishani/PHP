<?php
include 'php/header.php'; 
ob_start(); 

// Check if the 'loggedin' cookie is set and valid
if (!isset($_COOKIE['loggedin']) || $_COOKIE['loggedin'] != true) {
    header("Location: login.php");
    exit;
}

// Get username from cookie if available
$username = isset($_COOKIE['username']) ? htmlspecialchars($_COOKIE['username']) : 'Guest';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Cookie Assignment</title>
    <link rel="stylesheet" href="css/styles2.css">
</head>
<body>
    <div class="container">
        <h1>Cookie Assignment Dashboard</h1>
        <p>Welcome, <?= $username; ?>!</p>
        <p>This dashboard is part of an assignment that demonstrates the use of cookies in web development.</p>

        <h2>Understanding Cookies</h2>
        <p>In this assignment, cookies are used to keep track of the user's login status. When you successfully log in, a cookie named <strong>'loggedin'</strong> is set in your browser, which allows you to stay logged in for 2 minutes. After the cookie expires, you will be logged out automatically and redirected to the login page.</p>

        <h3>Cookie in Use:</h3>
        <p><strong>Cookie Name:</strong> loggedin</p>
        <p><strong>Value:</strong> <?= $_COOKIE['loggedin'] ?? 'Not Set'; ?></p>
        <p><strong>Expiration:</strong> <?= isset($_COOKIE['loggedin']) ? 'Expires in 2 minutes from the time of login.' : 'Expired or not logged in.'; ?></p>

        <p>If you want to update your profile or log out, you can use the following options:</p>

        <div class="update-container">
            <a href="update.php" class="update-button">Update Profile</a>
        </div>

        <div class="logout-container">
            <a href="logout.php" class="logout-button">Logout</a>
        </div>
    </div>
</body>
</html>

<?php
ob_end_flush(); 
include 'php/footer.php';
?>
