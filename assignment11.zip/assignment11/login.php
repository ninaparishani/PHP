<?php
include 'php/header.php'; 
ob_start();
require 'database.php';

// Handle logout request
if (isset($_GET['logout']) && $_GET['logout'] == 'true') {
    // Redirect to logout.php for cookie removal
    header("Location: logout.php");
    exit();
}

// Handle login form submission
if (isset($_POST['login'])) {
    // Get the username and password from the form
    $username = strip_tags($_POST['username']);
    $password = strip_tags($_POST['password']);
    
    $hashed_password = sha1($password);

    // Check if the username and hashed password exist in the database
    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$hashed_password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        // User found, set cookies
        setcookie('loggedin', 'true', time() + 120, "/", "", false, true); 
        setcookie('username', $username, time() + 120, "/", "", false, true); 


        header("Location: dashboard.php");
        exit();
    } else {
        $loginError = "Invalid username or password.";
    }
}

// Check if the user is logged in via the cookie
if (isset($_COOKIE['loggedin']) && $_COOKIE['loggedin'] === 'true') {
    header("Location: dashboard.php"); 
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/styles2.css">
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <?php if (isset($loginError)) : ?>
            <div class="error"><?= htmlspecialchars($loginError); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit" name="login">Login</button>
        </form>

        <p>Don't have an account? <a href="register.php">Register here</a></p>

        <?php if (isset($_COOKIE['loggedin']) && $_COOKIE['loggedin'] === 'true') : ?>
            <p><a href="logout.php">Logout</a></p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
ob_end_flush();
include 'php/footer.php';
?>
