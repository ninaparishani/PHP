<?php
// Remove the 'loggedin' and 'username' cookies by setting their expiration to a past time
setcookie('loggedin', '', time() - 3600, "/"); 
setcookie('username', '', time() - 3600, "/"); 

// Redirect to the login page or landing page after logout
header("Location: index.php"); 
exit();
?>
