<footer>
        <p>&copy; 2024 My Website</p>
</footer>
