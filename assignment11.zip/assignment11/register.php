<?php
include 'php/header.php'; 
require 'database.php'; 


if (isset($_POST['register'])) {
    $username = strip_tags($_POST['username']);
    $password = strip_tags(sha1($_POST['password']));
    $firstname = strip_tags($_POST['firstname']);
    $lastname = strip_tags($_POST['lastname']);
    $email = strip_tags($_POST['email']);

    // Insert new user into the database
    $sql = "INSERT INTO users (username, password, firstname, lastname, email) 
            VALUES ('$username', '$password', '$firstname', '$lastname', '$email')";
    if (mysqli_query($conn, $sql)) {
        // Redirect to login page after successful registration
        header("Location: login.php?registered=true");
        exit();
    } else {
        $registerError = "Error registering user: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="css/styles2.css"> 
</head>
<body>
    <div class="container">
        <h2>Register</h2>
        <?php if (isset($registerError)) : ?>
            <div class="error"><?= $registerError; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <label for="firstname">First Name:</label>
            <input type="text" id="firstname" name="firstname" required>

            <label for="lastname">Last Name:</label>
            <input type="text" id="lastname" name="lastname" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <button type="submit" name="register">Register</button>
        </form>
        

        <p>Already have an account? <a href="login.php">Login here</a></p>
    </div>
</body>
</html>
<?php

include 'php/footer.php';
?>