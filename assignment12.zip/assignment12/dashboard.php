<?php
session_start(); 
include 'php/header.php';

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php"); 
    exit();
}

// Check if username is stored in session
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/styles2.css">
</head>
<body>
    <div class="container">
        <h2>Welcome to the Dashboard</h2>
        <p>You are logged in as <strong><?php echo htmlspecialchars($username); ?></strong></p>

        <section class="assignment-info">
    <h3>Session Management Assignment</h3>
    <p>Welcome, <?php echo htmlspecialchars($username); ?>!</p>
    <p>This page demonstrates how sessions are used for user management in web development.</p>
    <p>Key Points About Sessions:</p>
    <ul>
        <li>Sessions are used to store data on the server side.</li>
        <li>Sessions help us remember user information across multiple pages.</li>
        <li>Session data is stored on the server, and only a session ID is sent to the client.</li>
        <li>Sessions are created when a user logs in and are destroyed when they log out.</li>
    </ul>
    <p>If you want to update your profile or log out, you can use the following options:</p>

</section>



        <div class="update-container">
            <a href="update.php" class="update-button">Update Profile</a>
        </div>

        <div class="logout-container">
            <a href="logout.php" class="logout-button">Logout</a>
        </div>
    </div>
</body>
</html>

<?php
include 'php/footer.php';
?>
