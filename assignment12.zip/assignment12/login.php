<?php

session_start(); 
ob_start(); 
require 'database.php'; 
include 'php/header.php';
// Check if the user is already logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header("Location: dashboard.php"); 
    exit();
}

// Login logic
if (isset($_POST['login'])) {
    $username = strip_tags($_POST['username']);
    $password = strip_tags($_POST['password']);
    $hashed_password = sha1($password); 


    $query = "SELECT * FROM users WHERE username = '$username' AND password = '$hashed_password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // Set the session variable to mark the user as logged in
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username; // Store username in session
        header("Location: dashboard.php"); 
        exit();
    } else {
        $loginError = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/styles2.css">
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <?php if (isset($loginError)) : ?>
            <div class="error"><?= $loginError; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit" name="login">Login</button>
        </form>
        <p>Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</body>
</html>

<?php
ob_end_flush();
include 'php/footer.php';
?>