<?php
session_start(); 
include 'php/header.php';
require 'database.php';

// Check if the user is logged in via the session
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

// Get the username from the session
$username = $_SESSION['username'];

// Fetch user details from the database
$sql = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
} else {
    echo "User not found.";
    exit();
}

// Update logic
if (isset($_POST['update'])) {
    $new_username = strip_tags($_POST['username']);
    $new_password = strip_tags($_POST['password']);
    $new_firstname = strip_tags($_POST['firstname']);
    $new_lastname = strip_tags($_POST['lastname']);
    $new_email = strip_tags($_POST['email']);

    // Start building the update query
    $updateFields = [];

    // Update username if it has changed
    if ($new_username !== $username) {
        $updateFields[] = "username = '$new_username'";
    }

    // Update password only if a new one is provided
    if (!empty($new_password)) {
        $hashed_password = sha1($new_password);
        $updateFields[] = "password = '$hashed_password'";
    }

    // Update other fields
    $updateFields[] = "firstname = '$new_firstname'";
    $updateFields[] = "lastname = '$new_lastname'";
    $updateFields[] = "email = '$new_email'";

    // Join the update fields to form the SET clause
    $updateQuery = "UPDATE users SET " . implode(", ", $updateFields) . " WHERE username = '$username'";

    if (mysqli_query($conn, $updateQuery)) {
        // Update session variable if the username was changed
        if ($new_username !== $username) {
            $_SESSION['username'] = $new_username;
        }

        // Redirect to dashboard after successful update
        header("Location: dashboard.php");
        exit();
    } else {
        $updateError = "Error updating user: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User</title>
    <link rel="stylesheet" href="css/styles2.css">
</head>
<body>
    <div class="container">
        <h2>Update User Information</h2>
        <?php if (isset($updateError)) : ?>
            <div class="error"><?= $updateError; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['username']); ?>" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" placeholder="Leave blank to keep current password">

            <label for="firstname">First Name:</label>
            <input type="text" id="firstname" name="firstname" value="<?= htmlspecialchars($user['firstname']); ?>" required>

            <label for="lastname">Last Name:</label>
            <input type="text" id="lastname" name="lastname" value="<?= htmlspecialchars($user['lastname']); ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']); ?>" required>

            <button type="submit" name="update">Update</button>
        </form>

        <p><a href="dashboard.php">Back to Dashboard</a></p>
    </div>
</body>
</html>

<?php
include 'php/footer.php';
?>
