<?php
session_start(); // Start the session
include 'php/header.php';

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

// Check if username is stored in session
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/styles2.css">
</head>
<body>
    <div class="container">
        <h2>Welcome to the Dashboard</h2>
        <p>You are logged in as <?= htmlspecialchars($username); ?></p>

        <h3>Assignment Overview</h3>
        <p>In this assignment, I implemented a secure login and registration system using PHP sessions. Below are the key features:</p>

        <ul>
            <li><strong>Login/Registration:</strong> The system allows users to register and login using their credentials. Sessions are used to keep track of logged-in users.</li>
            <li><strong>Session Management:</strong> After successfully logging in, a session is started, and the username is stored in the session. The session allows the user to navigate the dashboard and other secure pages without needing to log in again during their session.</li>
            <li><strong>Exception Handling:</strong> I incorporated `try-catch` blocks in the code to handle potential errors. This ensures that if an error occurs (e.g., a database connection fails), the system can gracefully log the error without crashing the application.</li>
            <li><strong>Error Logging:</strong> All errors encountered during login or registration are logged to 'logerrors.txt'. This helps in tracking any issues that users might face and provides a way for developers to debug problems. You can view the error messages for any exceptions that occurred during user interactions in the system.</li>
        </ul>

        <p>
            This approach ensures that the application remains robust and user-friendly while allowing developers to diagnose and fix any issues efficiently.
        </p>

        <a href="update.php">Update Your Information</a>
        <br>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>

<?php

include 'php/footer.php';
?>
