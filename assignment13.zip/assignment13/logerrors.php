<?php
// Set up error logging configuration
ini_set('log_errors', 1); // Enable error logging
ini_set('error_log', 'C:/wamp64/www/week 3/assignment13/logs/logerrors.txt'); // Specify log file path
error_reporting(E_ALL); // Report all errors


function logError($message) {
    $formattedMessage = "[" . date('Y-m-d H:i:s') . "] " . $message . PHP_EOL;

    // Log the error message to the file specified in error_log settings
    error_log($formattedMessage, 3, ini_get('error_log'));
}
?>
