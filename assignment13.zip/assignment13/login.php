<?php
session_start();
require 'database.php';
include 'logerrors.php';
include 'php/header.php';

// Check if the user is already logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header("Location: dashboard.php");
    exit();
}

if (isset($_POST['login'])) {
    try {
        // Get the username and password from the form
        $username = strip_tags($_POST['username']);
        $password = strip_tags($_POST['password']);
        $hashed_password = sha1($password);

        // Check if the username and hashed password exist in the database
        $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$hashed_password'";
        $result = mysqli_query($conn, $sql);

        if (!$result) {
            throw new Exception("Database query failed: " . mysqli_error($conn));
        }

        if (mysqli_num_rows($result) > 0) {
            // User found, start a session
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $username;

          
            header("Location: dashboard.php");
            exit();
        } else {
            $loginError = "Invalid username or password.";
        }
    } catch (Exception $e) {
        logError($e->getMessage());
        $loginError = "An error occurred. Please try again later.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/styles2.css">
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <?php if (isset($loginError)) : ?>
            <div class="error"><?= htmlspecialchars($loginError); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit" name="login">Login</button>
        </form>

        <p>Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</body>
</html>

<?php
include 'php/footer.php';
?>
