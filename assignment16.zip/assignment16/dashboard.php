<?php
session_start(); 
include 'php/header.php';

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php"); 
    exit();
}

// Check if username is stored in session
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/styles2.css">
</head>
<body>
    <div class="container">
        <h2>Welcome to the Dashboard</h2>
        <p>You are logged in as <?= htmlspecialchars($username); ?></p>

        <h3>Assignment Overview</h3>
        <p>In this assignment, I implemented several important features for a secure and user-friendly system. Below are the key aspects:</p>

        <ul>
            <li><strong>Login/Registration:</strong> The system allows users to register and log in securely. Sessions are used to maintain the user's logged-in state across pages, allowing for seamless navigation once authenticated.</li>
            <li><strong>Regular Expression Validation:</strong> To ensure data integrity, I added regular expression validation for the email field in both the registration and update forms. This ensures that only correctly formatted email addresses are accepted, improving the security and reliability of user data.</li>
            <li><strong>Session Management:</strong> Upon login, a session is started, and the user's details (e.g., username) are stored in the session. This enables the user to access restricted pages like the dashboard without needing to log in again until the session ends.</li>
            <li><strong>Exception Handling:</strong> I implemented `try-catch` blocks to handle errors and exceptions gracefully. If an error occurs, such as during database interactions, the system will log the error without crashing and notify the user with a friendly error message.</li>
            <li><strong>Error Logging:</strong> All system errors are logged in a file called 'logerrors.txt'. This helps developers debug issues by keeping track of any errors users encounter during their interactions with the system, ensuring problems can be diagnosed and fixed efficiently.</li>
        </ul>

        <p>
            These features ensure the application is secure, user-friendly, and robust, providing a smooth user experience while safeguarding data integrity and allowing developers to manage and resolve issues effectively.
        </p>

        <a href="update.php">Update Your Information</a>
        <br>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>

<?php
include 'php/footer.php';
?>
