<?php
session_start();
require 'database.php';
include 'logerrors.php';
include 'php/header.php';

// Check if the user is already logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header("Location: dashboard.php");
    exit();
}

if (isset($_POST['login'])) {
    try {
        // Get the username and password from the form
        $username = strip_tags($_POST['username']);
        $password = strip_tags($_POST['password']);

        // Check if the username exists in the database
        $sql = "SELECT * FROM users WHERE username = '$username'";
        $result = mysqli_query($conn, $sql);

        if (!$result) {
            throw new Exception("Database query failed: " . mysqli_error($conn));
        }

        if (mysqli_num_rows($result) > 0) {
            // User found, fetch the hashed password from the database
            $user = mysqli_fetch_assoc($result);
            $hashed_password = $user['password'];

            // Verify the password entered by the user against the hashed password
            if (password_verify($password, $hashed_password)) {
                // Password is correct, start a session
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $username;

                header("Location: dashboard.php");
                exit();
            } else {
                $loginError = "Invalid username or password.";
            }
        } else {
            $loginError = "Invalid username or password.";
        }
    } catch (Exception $e) {
        logError($e->getMessage());
        $loginError = "An error occurred. Please try again later.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/styles2.css">
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <?php if (isset($loginError)) : ?>
            <div class="error"><?= htmlspecialchars($loginError); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit" name="login">Login</button>
        </form>

        <p>Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</body>
</html>

<?php
include 'php/footer.php';
?>
