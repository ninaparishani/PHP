<?php
// Check if a session is already started before calling session_start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'database.php'; 
require_once 'logerrors.php'; 
include 'php/header.php';

date_default_timezone_set('America/New_York');

if (isset($_POST['register'])) {
    try {
        // Retrieve and sanitize input
        $username = strip_tags($_POST['username']);
        $password = strip_tags($_POST['password']);
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $firstname = strip_tags($_POST['firstname']);
        $lastname = strip_tags($_POST['lastname']);
        $email = strip_tags($_POST['email']);
        $province = strip_tags($_POST['province']); 

        // Check if any field is empty
        if (empty($username) || empty($password) || empty($firstname) || empty($lastname) || empty($email) || empty($province)) {
            throw new Exception('All fields are required, including province.');
        }

        // Regular expression to validate email format
        $emailPattern = "/^[\w\.-]+@[a-zA-Z\d\.-]+\.[a-zA-Z]{2,6}$/";

        // Validate email format
        if (!preg_match($emailPattern, $email)) {
            throw new Exception('Invalid email format.');
        }

        // Check if the username already exists
        $checkSql = "SELECT * FROM users WHERE username = '$username'";
        $checkResult = mysqli_query($conn, $checkSql);
        if (!$checkResult) {
            throw new Exception('Error checking username: ' . mysqli_error($conn));
        }

        if (mysqli_num_rows($checkResult) > 0) {
            throw new Exception('Username already exists.');
        }

        // Insert new user into database
        $sql = "INSERT INTO users (username, password, firstname, lastname, email, province) 
                VALUES ('$username', '$hashed_password', '$firstname', '$lastname', '$email', '$province')";
        if (!mysqli_query($conn, $sql)) {
            throw new Exception('Error registering user: ' . mysqli_error($conn));
        }

        // Redirect to login page after successful registration
        header("Location: login.php?registered=true");
        exit();

    } catch (Exception $e) {
        // Log errors and display a user-friendly message
        $timestamp = date('Y-m-d H:i:s');
        $message = "[$timestamp] Exception caught: " . $e->getMessage();
        logError($message);
        $registerError = "An error occurred during registration. Please try again later.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="css/styles2.css">
</head>
<body>
    <div class="container">
        <h2>Register</h2>
        <?php if (isset($registerError)) : ?>
            <div class="error"><?= htmlspecialchars($registerError); ?></div>
        <?php endif; ?>
        <form method="POST" action="register.php">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <label for="firstname">First Name:</label>
            <input type="text" id="firstname" name="firstname" required>

            <label for="lastname">Last Name:</label>
            <input type="text" id="lastname" name="lastname" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="province">Province:</label>
            <select id="province" name="province" required>
                <option value="">Select a Province</option>
                <option value="Ontario">Ontario</option>
                <option value="Quebec">Quebec</option>
                <option value="British Columbia">British Columbia</option>
                <option value="Alberta">Alberta</option>
            </select>

            <button type="submit" name="register">Register</button>
        </form>
        <p>Already have an account? <a href="login.php">Login here</a></p>
    </div>
</body>
</html>

<?php
include 'php/footer.php';
?>
