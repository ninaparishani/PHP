<?php
session_start();
include 'php/header.php';
require 'database.php';
include 'logerrors.php';

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

// Check if username is stored in session
$username = $_SESSION['username'] ?? 'Guest';

// Fetch user details from the database
try {
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $sql);

    if (!$result || mysqli_num_rows($result) == 0) {
        throw new Exception("User not found.");
    }

    $user = mysqli_fetch_assoc($result);
} catch (Exception $e) {
    logError($e->getMessage());
    echo "An error occurred. Please try again later.";
    exit();
}

// Update logic
if (isset($_POST['update'])) {
    try {
        $new_username = strip_tags($_POST['username']);
        $new_password = strip_tags($_POST['password']);
        $new_firstname = strip_tags($_POST['firstname']);
        $new_lastname = strip_tags($_POST['lastname']);
        $new_email = strip_tags($_POST['email']);

        // Validate email with regular expression
        if (!preg_match("/^[\w\-\.]+@([\w\-]+\.)+[\w\-]{2,4}$/", $new_email)) {
            throw new Exception("Invalid email format.");
        }


        $updateFields = [];
        
        if ($new_username !== $username) {
            $updateFields[] = "username = '$new_username'";
        }

        if (!empty($new_password)) {
            $hashed_password = sha1($new_password);
            $updateFields[] = "password = '$hashed_password'";
        }

        $updateFields[] = "firstname = '$new_firstname'";
        $updateFields[] = "lastname = '$new_lastname'";
        $updateFields[] = "email = '$new_email'";

        $updateQuery = "UPDATE users SET " . implode(", ", $updateFields) . " WHERE username = '$username'";
        
        if (!mysqli_query($conn, $updateQuery)) {
            throw new Exception("Error updating user: " . mysqli_error($conn));
        }

        if ($new_username !== $username) {
            $_SESSION['username'] = $new_username;
        }

        header("Location: dashboard.php");
        exit();
    } catch (Exception $e) {
        logError($e->getMessage());
        $updateError = $e->getMessage(); // Show the specific error message
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User</title>
    <link rel="stylesheet" href="css/styles2.css">
</head>
<body>
    <div class="container">
        <h2>Update User Information</h2>
        <?php if (isset($updateError)) : ?>
            <div class="error"><?= htmlspecialchars($updateError); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['username']); ?>" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" placeholder="Leave blank to keep current password">

            <label for="firstname">First Name:</label>
            <input type="text" id="firstname" name="firstname" value="<?= htmlspecialchars($user['firstname']); ?>" required>

            <label for="lastname">Last Name:</label>
            <input type="text" id="lastname" name="lastname" value="<?= htmlspecialchars($user['lastname']); ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']); ?>" required>

            <button type="submit" name="update">Update</button>
        </form>

        <p><a href="dashboard.php">Back to Dashboard</a></p>
    </div>
</body>
</html>

<?php
include 'php/footer.php';
?>
