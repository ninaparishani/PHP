<?php
function isDecimal($input) {
    // Regular expression for decimal number (must have a decimal point and at least one digit after it)
    $regex = '/^[+-]?\d+\.\d+$/';
    
    // Test if input matches the decimal regex pattern
    return preg_match($regex, $input);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Decimal Validation</title>
</head>
<body>
    <h2>Decimal Validator</h2>
    
    <form action="" method="POST">
        <label for="number">Enter a number:</label>
        <input type="text" name="number" id="number" required>
        <button type="submit">Check</button>
    </form>

    <?php
    // Check if the form has been submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $input = $_POST['number']; // Get user input from the form

        // Validate if input is a decimal
        if (isDecimal($input)) {
            echo "<p>The input <strong>'$input'</strong> is a valid decimal number.</p>";
        } else {
            echo "<p>The input <strong>'$input'</strong> is NOT a valid decimal number.</p>";
        }
    }
    ?>
</body>
</html>
