<?php
// Include the header
include 'php/header.php';
?>

<main>
    <div class="container">
        <!-- Text Area -->
        <div class="text-area">
            <h2>Introduction</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <img src="images/image.jpg" alt="Descriptive Text" class="left-image" />
            <p>Quisque integer efficitur eget morbi taciti laoreet et posuere. Eu ullamcorper est curae turpis accumsan facilisis. Magnis tortor nunc tempor in tellus risus in gravida dictum. Pellentesque finibus ad lacus natoque iaculis imperdiet velit facilisi. Et fusce torquent ultrices tristique venenatis pellentesque suspendisse ex. Dis blandit aptent venenatis pharetra quis. Taciti rutrum sapien massa proin, dignissim dapibus iaculis nisi. Semper a proin justo class sollicitudin elit auctor. Sodales morbi per enim nisl dictum nunc vulputate. Aptent suspendisse porttitor malesuada sodales ultrices.</p>
            <p>Pretium magnis elementum potenti ac potenti egestas ullamcorper pharetra. Ligula sollicitudin feugiat nisl dignissim rhoncus. Scelerisque quisque porttitor; leo ullamcorper dui dictum. Consequat nibh vitae condimentum primis felis dignissim augue. Eleifend blandit erat litora suscipit vel ad; a nisi. Ut congue efficitur potenti litora quis dui in; cursus eget. Sociosqu mollis potenti felis quisque aenean odio. Vitae nullam ullamcorper proin cras sed dignissim.</p>
            <p>Dis at interdum curae placerat quis. Vivamus ipsum bibendum nostra risus laoreet consequat fusce aptent mauris. Elementum fringilla hac suscipit arcu nostra nullam? Magna inceptos vehicula eros quam est montes cursus. Nascetur inceptos sapien primis, etiam tempus efficitur. Vulputate ullamcorper potenti ipsum dui; dignissim malesuada? Turpis quam fringilla quam maecenas condimentum.</p>
            <p>At mi hac pulvinar ultricies curabitur, tincidunt sodales felis? Sagittis duis platea arcu himenaeos netus est. Magna eu porta eget; vestibulum proin neque massa libero. Pellentesque sem fusce potenti convallis at porttitor? Cras ac duis primis nam curabitur. Pulvinar ornare himenaeos tristique; viverra ultrices volutpat viverra conubia. Quam tincidunt libero at sociosqu facilisi molestie proin fringilla. Elementum torquent lacus ut gravida mattis vehicula varius erat neque.</p>
        </div>

        <!-- Widgets Area -->
        <div class="widgets">
            <!-- Widget 1 -->
            <div class="widget">
                Widget1 Text
            </div>

            <!-- Widget 2 -->
            <div class="widget">
                Widget2 Text
            </div>

            <!-- Widget 3 -->
            <div class="widget">
                Widget3 Text
            </div>
        </div>
    </div>
</main>

<?php
// Include the footer
include 'php/footer.php';
?>
