<?php
// Include the header
include 'php/header.php';
?>

<main>
<div class="container">
    <!-- Form Container -->
    <div class="form-container">
            <h2>User Registration Form</h2>
            <form action="" method="post">
                <!-- Form fields here -->
                <label for="username">Username:</label><br>
                <input type="text" id="username" name="username" required><br><br>

                <label for="firstname">First Name:</label><br>
                <input type="text" id="firstname" name="firstname" required><br><br>

                <label for="lastname">Last Name:</label><br>
                <input type="text" id="lastname" name="lastname" required><br><br>

                <label for="password">Password:</label><br>
                <input type="password" id="password" name="password" required><br><br>

                <label for="confirm_password">Confirm Password:</label><br>
                <input type="password" id="confirm_password" name="confirm_password" required><br><br>

                <label for="email">Email:</label><br>
                <input type="text" id="email" name="email" required><br><br>

                <label for="province">Province:</label><br>
                <select id="province" name="province" required>
                    <option value="ON">Ontario</option>
                    <option value="QC">Quebec</option>
                    <option value="BC">British Columbia</option>
                    <option value="AB">Alberta</option>
                </select><br><br>

                <label for="accept_terms">
                    <input type="checkbox" id="accept_terms" name="accept_terms" required> Accept Terms
                </label><br><br>

                <input type="submit" value="Submit">
            </form>
        </div>

        <!-- Widgets Area -->
        <div class="widgets">
            <!-- Widget 1 -->
            <div class="widget">
                Widget1 Text
            </div>

            <!-- Widget 2 -->
            <div class="widget">
                Widget2 Text
            </div>

            <!-- Widget 3 -->
            <div class="widget">
                Widget3 Text
            </div>
        </div>
    </div>
</main>

<?php
// Include the footer
include 'php/footer.php';
?>
