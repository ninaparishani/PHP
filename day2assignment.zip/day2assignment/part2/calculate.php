<?php
function calculate($number1, $number2, $operator = 'a') {
    // Initialize result variable
    $result = 0;

    // Perform the calculation based on the operator
    switch ($operator) {
        case 'a': // Addition
            $result = $number1 + $number2;
            break;
        case 's': // Subtraction
            $result = $number1 - $number2;
            break;
        case 'd': // Division
            if ($number2 != 0) { // Check to avoid division by zero
                $result = $number1 / $number2;
            } else {
                return "Error: Division by zero";
            }
            break;
        case 'm': // Multiplication
            $result = $number1 * $number2;
            break;
        default:
            return "Error: Invalid operator";
    }

    // Return the result
    return $result;
}

// Test the function
$added = calculate(36, 42);
echo "Number 1 = 36<br/>Number 2 = 42<br/>Operator = \"a\"<br/>Result = $added<br/><br/>";

$subbed = calculate(55, 99, "s");
echo "Number 1 = 55<br/>Number 2 = 99<br/>Operator = \"s\"<br/>Result = $subbed<br/><br/>";

$multiplied = calculate(3, 78, "m");
echo "Number 1 = 3<br/>Number 2 = 78<br/>Operator = \"m\"<br/>Result = $multiplied<br/><br/>";

$divided = calculate(12, 3, "d");
echo "Number 1 = 12<br/>Number 2 = 3<br/>Operator = \"d\"<br/>Result = $divided<br/><br/>";
?>
