<?php
// Define an array with 10 names
$names = [
    0=> "Tom",
    1=>"Robert",
    2=>"Charlie",
    3=>"Emma",
    4=>"David",
    5=>"Sam",
    6=>"Sally",
    7=>"Nikki",
    8=>"Jake",
    9=>"John"
];
?>
<?php
// Output names with their positions
echo "<h2>Names in Forward Order:</h2>";
for ($i = 0; $i < count($names); $i++) {
    echo "Name at position " . ($i + 1) . " is: " . $names[$i] . "<br>";
}
?>
<?php
// Output names in reverse order
echo "<h2>Names in Reverse Order:</h2>";
for ($i = count($names) - 1; $i >= 0; $i--) {
    echo "Name at position " . ($i + 1) . " is: " . $names[$i] . "<br>";
}
?>
