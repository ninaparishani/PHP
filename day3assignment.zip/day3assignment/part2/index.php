<?php
// Include the header
include 'php/header.php';

// Initialize variables for form data
$formData = [
    'username' => '',
    'firstname' => '',
    'lastname' => '',
    'password' => '',
    'confirm_password' => '',
    'email' => '',
    'province' => '',
    'accept_terms' => ''
];

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Store form data
    $formData['username'] = htmlspecialchars($_POST['username']);
    $formData['firstname'] = htmlspecialchars($_POST['firstname']);
    $formData['lastname'] = htmlspecialchars($_POST['lastname']);
    $formData['password'] = htmlspecialchars($_POST['password']);
    $formData['confirm_password'] = htmlspecialchars($_POST['confirm_password']);
    $formData['email'] = htmlspecialchars($_POST['email']);
    $formData['province'] = htmlspecialchars($_POST['province']);
    $formData['accept_terms'] = isset($_POST['accept_terms']) ? 'True' : 'False';
}
?>

<main>
<div class="container">
    <!-- Form Container -->
    <div class="form-container">
        <h2>User Registration Form</h2>
        <form action="" method="post">
            <label for="username">Username:</label><br>
            <input type="text" id="username" name="username" required value="<?php echo htmlspecialchars($formData['username']); ?>"><br><br>

            <label for="firstname">First Name:</label><br>
            <input type="text" id="firstname" name="firstname" required value="<?php echo htmlspecialchars($formData['firstname']); ?>"><br><br>

            <label for="lastname">Last Name:</label><br>
            <input type="text" id="lastname" name="lastname" required value="<?php echo htmlspecialchars($formData['lastname']); ?>"><br><br>

            <label for="password">Password:</label><br>
            <input type="password" id="password" name="password" required value="<?php echo htmlspecialchars($formData['password']); ?>"><br><br>

            <label for="confirm_password">Confirm Password:</label><br>
            <input type="password" id="confirm_password" name="confirm_password" required value="<?php echo htmlspecialchars($formData['confirm_password']); ?>"><br><br>

            <label for="email">Email:</label><br>
            <input type="text" id="email" name="email" required value="<?php echo htmlspecialchars($formData['email']); ?>"><br><br>

            <label for="province">Province:</label><br>
            <select id="province" name="province" required>
                <option value="ON" <?php if ($formData['province'] == 'ON') echo 'selected'; ?>>Ontario</option>
                <option value="QC" <?php if ($formData['province'] == 'QC') echo 'selected'; ?>>Quebec</option>
                <option value="BC" <?php if ($formData['province'] == 'BC') echo 'selected'; ?>>British Columbia</option>
                <option value="AB" <?php if ($formData['province'] == 'AB') echo 'selected'; ?>>Alberta</option>
            </select><br><br>

            <label for="accept_terms">
                <input type="checkbox" id="accept_terms" name="accept_terms" <?php if ($formData['accept_terms'] == 'True') echo 'checked'; ?>> Accept Terms
            </label><br><br>

            <input type="submit" value="Submit">
        </form>
    </div>

    <!-- Display User Input -->
    <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
    <div class="user-input">
        <h2>Your Input</h2>
        <p>Username: <?php echo $formData['username']; ?></p>
        <p>Name: <?php echo $formData['firstname'] . " " . $formData['lastname']; ?></p>
        <p>Password: <?php echo $formData['password']; ?></p>
        <p>Email: <?php echo $formData['email']; ?></p>
        <p>Province: <?php echo $formData['province']; ?></p>
        <p>Accept Terms: <?php echo $formData['accept_terms']; ?></p>
    </div>
    <?php endif; ?>

    <!-- Widgets Area -->
    <div class="widgets">
        <!-- Widget 1 -->
        <div class="widget">
            Widget1 Text
        </div>

        <!-- Widget 2 -->
        <div class="widget">
            Widget2 Text
        </div>

        <!-- Widget 3 -->
        <div class="widget">
            Widget3 Text
        </div>
    </div>
</div>
</main>

<?php
// Include the footer
include 'php/footer.php';
?>
