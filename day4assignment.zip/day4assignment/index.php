<?php
// Include the header
include 'php/header.php';

// Initialize variables for form data and validation errors
$formData = [
    'username' => '',
    'firstname' => '',
    'lastname' => '',
    'password' => '',
    'confirm_password' => '',
    'email' => '',
    'province' => '',
    'accept_terms' => ''
];

$errors = [];

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Store form data
    $formData['username'] = htmlspecialchars($_POST['username']);
    $formData['firstname'] = htmlspecialchars($_POST['firstname']);
    $formData['lastname'] = htmlspecialchars($_POST['lastname']);
    $formData['password'] = htmlspecialchars($_POST['password']);
    $formData['confirm_password'] = htmlspecialchars($_POST['confirm_password']);
    $formData['email'] = htmlspecialchars($_POST['email']);
    $formData['province'] = htmlspecialchars($_POST['province']);
    $formData['accept_terms'] = isset($_POST['accept_terms']) ? 'True' : 'False';

    // Validate form data
    if (empty($formData['username'])) {
        $errors[] = "Username is required.";
    }
    if (empty($formData['firstname'])) {
        $errors[] = "First Name is required.";
    }
    if (empty($formData['lastname'])) {
        $errors[] = "Last Name is required.";
    }
    if (empty($formData['password'])) {
        $errors[] = "Password is required.";
    }
    if (empty($formData['confirm_password'])) {
        $errors[] = "Confirm Password is required.";
    }
    if ($formData['password'] !== $formData['confirm_password']) {
        $errors[] = "Passwords do not match.";
    }
    if (empty($formData['email'])) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }
    if (empty($formData['province'])) {
        $errors[] = "Province is required.";
    }
    if (empty($formData['accept_terms'])) {
        $errors[] = "You must accept the terms.";
    }

    // Display errors or form data
    $displayResults = '';
    if (empty($errors)) {
        $displayResults = "<h2>Your Input</h2>";
        $displayResults .= "Username: " . $formData['username'] . "<br>";
        $displayResults .= "Name: " . $formData['firstname'] . " " . $formData['lastname'] . "<br>";
        $displayResults .= "Password: " . $formData['password'] . "<br>";
        $displayResults .= "Email: " . $formData['email'] . "<br>";
        $displayResults .= "Province: " . $formData['province'] . "<br>";
        $displayResults .= "Accept Terms: " . $formData['accept_terms'] . "<br>";
    } else {
        foreach ($errors as $error) {
            $displayResults .= "<p style='color: red;'>$error</p>";
        }
    }
}
?>

<main>
<div class="container">
    <!-- Form Container -->
    <div class="form-container">
        <h2>User Registration Form</h2>
        <form action="" method="post">
            <label for="username">Username:</label><br>
            <input type="text" id="username" name="username" required value="<?php echo htmlspecialchars($formData['username']); ?>"><br><br>

            <label for="firstname">First Name:</label><br>
            <input type="text" id="firstname" name="firstname" required value="<?php echo htmlspecialchars($formData['firstname']); ?>"><br><br>

            <label for="lastname">Last Name:</label><br>
            <input type="text" id="lastname" name="lastname" required value="<?php echo htmlspecialchars($formData['lastname']); ?>"><br><br>

            <label for="password">Password:</label><br>
            <input type="password" id="password" name="password" required value="<?php echo htmlspecialchars($formData['password']); ?>"><br><br>

            <label for="confirm_password">Confirm Password:</label><br>
            <input type="password" id="confirm_password" name="confirm_password" required value="<?php echo htmlspecialchars($formData['confirm_password']); ?>"><br><br>

            <label for="email">Email:</label><br>
            <input type="text" id="email" name="email" required value="<?php echo htmlspecialchars($formData['email']); ?>"><br><br>

            <label for="province">Province:</label><br>
            <select id="province" name="province" required>
                <option value="ON" <?php if ($formData['province'] == 'ON') echo 'selected'; ?>>Ontario</option>
                <option value="QC" <?php if ($formData['province'] == 'QC') echo 'selected'; ?>>Quebec</option>
                <option value="BC" <?php if ($formData['province'] == 'BC') echo 'selected'; ?>>British Columbia</option>
                <option value="AB" <?php if ($formData['province'] == 'AB') echo 'selected'; ?>>Alberta</option>
            </select><br><br>

            <label for="accept_terms">
                <input type="checkbox" id="accept_terms" name="accept_terms" <?php if ($formData['accept_terms'] == 'True') echo 'checked'; ?>> Accept Terms
            </label><br><br>

            <input type="submit" value="Submit">
        </form>
    </div>

    <!-- Results Container -->
    <div class="results-container">
        <!-- Display Results Here -->
        <?php if (isset($displayResults)) echo $displayResults; ?>
    </div>

    <!-- Widgets Area -->
    <div class="widgets">
        <!-- Widget 1 -->
        <div class="widget">
            Widget1 Text
        </div>

        <!-- Widget 2 -->
        <div class="widget">
            Widget2 Text
        </div>

        <!-- Widget 3 -->
        <div class="widget">
            Widget3 Text
        </div>
    </div>
</div>
</main>

<?php
// Include the footer
include 'php/footer.php';
?>
