<footer>
    <div class="container">
        <p>&copy; 2024 My Website</p>
    </div>
</footer>
