<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Basic Page Layout</title>
    <link rel="stylesheet" href="css/styles.css"> 
</head>
<body>
    <header>
        <h1>Welcome to My Website</h1>
    </header>
