<?php
// Include the header and database connection
include 'php/header.php';
include 'php/database.php';

// Initialize variables
$user = [
    'username' => '',
    'firstname' => '',
    'lastname' => '',
    'email' => '',
    'province' => ''
];
$errors = [];
$id = null;

// Check if editid is provided
if (isset($_GET['editid']) && !empty($_GET['editid'])) {
    $id = intval($_GET['editid']); // Ensure the ID is an integer

    // Fetch user data for the given ID
    $query = "SELECT username, firstname, lastname, email, province FROM users WHERE id = $id";
    $result = $mysqli->query($query);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        echo "<p style='color: red;'>User not found.</p>";
    }
} else {
    echo "<p style='color: red;'>No user ID provided.</p>";
}

// Handle form submission for updating user
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $user['username'] = htmlspecialchars($_POST['username']);
    $user['firstname'] = htmlspecialchars($_POST['firstname']);
    $user['lastname'] = htmlspecialchars($_POST['lastname']);
    $user['email'] = htmlspecialchars($_POST['email']);
    $user['province'] = htmlspecialchars($_POST['province']);
    $id = intval($_POST['editid']); // Ensure ID is an integer

    // Validate form data
    if (empty($user['username'])) $errors[] = "Username is required.";
    if (empty($user['firstname'])) $errors[] = "First Name is required.";
    if (empty($user['lastname'])) $errors[] = "Last Name is required.";
    if (empty($user['email'])) $errors[] = "Email is required.";
    elseif (!filter_var($user['email'], FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format.";
    if (empty($user['province'])) $errors[] = "Province is required.";

    // Update user in the database if no errors
    if (empty($errors)) {
        $sql = "UPDATE users SET 
                    username = '{$user['username']}', 
                    firstname = '{$user['firstname']}', 
                    lastname = '{$user['lastname']}', 
                    email = '{$user['email']}', 
                    province = '{$user['province']}' 
                WHERE id = $id";

        if ($mysqli->query($sql) === TRUE) {
            echo "<h2>User Updated Successfully!</h2>";
        } else {
            echo "<p style='color: red;'>Error: " . $mysqli->error . "</p>";
        }
    } else {
        foreach ($errors as $error) {
            echo "<p style='color: red;'>$error</p>";
        }
    }
}
?>

<main>
    <div class="container">
        <div class="form-container">
            <h2>Edit User Information</h2>

            <div class="link-container">
                <!-- Back to index link -->
                <p><a href="index.php">Back to user management</a></p>
            </div>

            <?php if ($id): ?>
                <form action="" method="post">
                    <!-- Hidden field for editid -->
                    <input type="hidden" name="editid" value="<?php echo htmlspecialchars($id); ?>">

                    <label for="username">Username:</label><br>
                    <input type="text" id="username" name="username" required value="<?php echo htmlspecialchars($user['username']); ?>"><br><br>

                    <label for="firstname">First Name:</label><br>
                    <input type="text" id="firstname" name="firstname" required value="<?php echo htmlspecialchars($user['firstname']); ?>"><br><br>

                    <label for="lastname">Last Name:</label><br>
                    <input type="text" id="lastname" name="lastname" required value="<?php echo htmlspecialchars($user['lastname']); ?>"><br><br>

                    <label for="email">Email:</label><br>
                    <input type="text" id="email" name="email" required value="<?php echo htmlspecialchars($user['email']); ?>"><br><br>

                    <label for="province">Province:</label><br>
                    <select id="province" name="province" required>
                        <option value="">Select a province</option>
                        <option value="ON" <?php if ($user['province'] == 'ON') echo 'selected'; ?>>Ontario</option>
                        <option value="QC" <?php if ($user['province'] == 'QC') echo 'selected'; ?>>Quebec</option>
                        <option value="BC" <?php if ($user['province'] == 'BC') echo 'selected'; ?>>British Columbia</option>
                        <option value="AB" <?php if ($user['province'] == 'AB') echo 'selected'; ?>>Alberta</option>
                    </select><br><br>

                    <input type="submit" name="update" value="Update">
                </form>
            <?php endif; ?>
        </div>

        <div class="widgets">
            <div class="widget">Widget 1</div>
            <div class="widget">Widget 2</div>
            <div class="widget">Widget 3</div>
        </div>
    </div>
</main>

<?php
// Include the footer
include 'php/footer.php';
?>
