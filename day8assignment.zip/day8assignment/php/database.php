<?php
// Database connection details
$servername = "127.0.0.1";
$dbname = "store";
$dbusername = "root";
$dbpassword = "";

// Create connection
$mysqli = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}
?>
