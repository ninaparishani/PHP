<?php
// Include the header and database connection
include 'php/header.php';
include 'php/database.php';

// Check if the delete request was made through GET
if (isset($_GET['deleteid'])) {
    $delid = intval($_GET['deleteid']); // Ensure ID is an integer

    // Check if the ID is valid
    if (!empty($delid)) {
        // Perform the delete query
        $delete_query = "DELETE FROM users WHERE id = $delid";

        if ($mysqli->query($delete_query)) {
            $message = "<p style='color: green;'>User deleted successfully!</p>";
        } else {
            $message = "<p style='color: red;'>Error: " . $mysqli->error . "</p>";
        }
    } else {
        $message = "<p style='color: red;'>Invalid user ID.</p>";
    }
} else {
    $message = "<p style='color: red;'>No user ID provided.</p>";
}
?>

<main>
    <div class="container">
        <h2>Delete User</h2>
        <?php
        // Display the success or error message
        echo $message;
        ?>
        <p><a href="index.php">Back to User Management</a></p>
    </div>
</main>

<?php
// Include the footer
include 'php/footer.php';
?>
