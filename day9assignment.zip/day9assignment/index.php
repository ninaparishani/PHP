<?php
// Include the header and database connection
include 'php/header.php';
include 'php/database.php';

// Fetch all users
$users_result = $mysqli->query("SELECT id, username, firstname, lastname, email, province FROM users");
?>

<main>
    <div class="container">
        <div class="main-content">
            <h2>Manage Users</h2>

            <table border="1" cellpadding="10">
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Email</th>
                    <th>Province</th>
                    <th>Actions</th>
                </tr>
                <?php while ($row = $users_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                    <td><?php echo htmlspecialchars($row['firstname']); ?></td>
                    <td><?php echo htmlspecialchars($row['lastname']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['province']); ?></td>
                    <td>
                        <!-- Link to edit the user -->
                        <a href="edit_user.php?editid=<?php echo $row['id']; ?>">Edit</a>
                        
                        <!-- Link to delete the user -->
                        <a href="delete_user.php?deleteid=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </table>
        </div>

        <!-- Widget Area -->
        <div class="widgets">
            <div class="widget">
                <h3>Widget 1</h3>

            </div>
            <div class="widget">
                <h3>Widget 2</h3>

            </div>
            <div class="widget">
                <h3>Widget 3</h3>

            </div>
        </div>
    </div>
</main>

<?php
// Include the footer
include 'php/footer.php';
?>
